#include "output.h"

output::output()
{
    //ctor
}

output::~output()
{
    //dtor
}
